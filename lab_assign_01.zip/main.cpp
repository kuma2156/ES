#include "mbed.h"

#define GREEN_LED_PIN PA_13
#define YELLOW_LED_PIN PB_10
#define RED_LED_PIN PA_4

#define BTN_1_PIN PA_14
#define BTN_2_PIN PB_7
#define BTN_3_PIN PC_4

DigitalOut greenLed(GREEN_LED_PIN);
DigitalOut yellowLed(YELLOW_LED_PIN);
DigitalOut redLed(RED_LED_PIN);

DigitalIn Button1(BTN_1_PIN);
DigitalIn Button2(BTN_2_PIN);
DigitalIn Button3(BTN_3_PIN);

int ledBlinky = 1;
Timer blinkyTm;

typedef enum
{
    NO_EDGE = 0, RISING_EDGE , FALLING_EDGE
} edge_t;

edge_t detectionBtn3Edge()
{
    static int prevState = 1;
    edge_t edge = NO_EDGE;

    int currState = Button3;
    if(currState != prevState)
    {
        wait_ms(50); //debouncing delay 50 ms
        currState = Button3;
        if(currState != prevState)
        {
           if(currState == 1) edge = RISING_EDGE;
           else edge = FALLING_EDGE;

           prevState = currState; // update
        }
    }
    return edge;
}
edge_t detectionBtn1Edge()
{
    static int prevState = 1;
    edge_t edge = NO_EDGE;

    int currState = Button1;
    if(currState != prevState)
    {
        wait_ms(50); //debouncing delay 50 ms
        currState = Button1;
        if(currState != prevState)
        {
            if(currState == 1) edge = RISING_EDGE;
            else edge = FALLING_EDGE;

            prevState = currState; // update
        }
    }
    return edge;
}
edge_t detectionBtn2Edge()
{
    static int prevState = 1;
    edge_t edge = NO_EDGE;

    int currState = Button2;
    if(currState != prevState)
    {
        wait_ms(50); //debouncing delay 50 ms
        currState = Button2;
        if(currState != prevState)
        {
            if(currState == 1) edge = RISING_EDGE;
            else edge = FALLING_EDGE;

            prevState = currState; // update
        }
    }
    return edge;
}

void setup()
{
    greenLed = 0;
    blinkyTm.start();
}

int main()
{
    setup();
    int key = 0;
    int lastClickTime = 0;
		int second = 1000;

    while(1)
    {
				// button1
				if(detectionBtn1Edge() == RISING_EDGE)
				{
					int currTime = blinkyTm.read_ms();
					  if (currTime - lastClickTime < second)
						{
							if(second < 400) continue;
							second -= 300;
            }
					lastClickTime = currTime;
				}
				// button2 
				if(detectionBtn2Edge() == RISING_EDGE)
				{
					int currTime = blinkyTm.read_ms();
					  if (currTime - lastClickTime < second)
						{
							if(second > 2000) continue;
							second += 300;
            }
					lastClickTime = currTime;
				}
				// key change and blink
				if (ledBlinky)
        {
            if(blinkyTm.read_ms() >= second)
            {
                blinkyTm.reset();
                if(key == 0)
                {
                    greenLed = !greenLed;
                    yellowLed = 0;
                    redLed = 0;
                }
                else if(key == 1)
                {
                    greenLed = 0;
                    yellowLed = 0;
                    redLed = !redLed;
                }
                else if(key == 2)
                {
                    greenLed = 0;
                    yellowLed = !yellowLed;
                    redLed = 0;
                }
            }
        }
				// button3
        if(detectionBtn3Edge() == RISING_EDGE)
        {
            int currTime = blinkyTm.read_ms();
            if (currTime - lastClickTime < second) { // if the last click was within 1 sec, switch to the next LED
                if(key == 2) key = 0;
                else key++;
            }
            lastClickTime = currTime;
        }
    }
}
